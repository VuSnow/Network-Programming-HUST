#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s IP_Addr Port_Number\n", argv[0]);
        return 1;
    }

    char *server_ip = argv[1];
    int port = atoi(argv[2);
    int client_socket;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];

    // Create a socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        perror("Error in socket");
        exit(1);
    }

    // Set up server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = inet_addr(server_ip);

    // Connect to the server
    if (connect(client_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Error in connect");
        close(client_socket);
        exit(1);
    }

    char file_path[BUFFER_SIZE];
    int file_name_length;

    while (1) {
        printf("Enter the file path (or press Enter to exit): ");
        if (fgets(file_path, BUFFER_SIZE, stdin) == NULL) {
            break;
        }

        // Remove newline character from the file path
        file_path[strcspn(file_path, "\n")] = '\0';

        if (strlen(file_path) == 0) {
            break;
        }

        // Extract the file name from the path
        char *file_name = strrchr(file_path, '/');
        if (file_name == NULL) {
            file_name = file_path;
        } else {
            file_name++;
        }

        // Send the file name to the server
        file_name_length = strlen(file_name);
        send(client_socket, &file_name_length, sizeof(file_name_length), 0);
        send(client_socket, file_name, file_name_length, 0);

        // Check if the file exists
        recv(client_socket, buffer, 7, 0);
        if (strcmp(buffer, "EXISTED") == 0) {
            printf("%s Error: File is existed on server\n", file_name);
            continue;
        }

        // Open the file and send its content
        FILE *file = fopen(file_path, "rb");
        if (file == NULL) {
            perror("Error in opening file");
            continue;
        }

        int read_bytes;
        while (1) {
            read_bytes = fread(buffer, 1, BUFFER_SIZE, file);
            if (read_bytes <= 0) {
                break;
            }
            send(client_socket, buffer, read_bytes, 0);
        }

        fclose(file);

        // Receive the server's acknowledgment
        recv(client_socket, buffer, 2, 0);
        if (strcmp(buffer, "OK") == 0) {
            printf("%s Transfer complete\n", file_name);
        }
    }

    close(client_socket);
    return 0;
}
