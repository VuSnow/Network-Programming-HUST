#include <arpa/inet.h> /* These are the usual header files */
#include <ctype.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define CMD_SIZE 1024
#define MSG_SIZE 8192
#define RES_SIZE CMD_SIZE + MSG_SIZE
#define MAX_FILE_SIZE (100 * 1024 * 1024) // 100MB

int LISTENQ = 8;
int PORT_NUM, listen_sock, conn_sock;
char res[RES_SIZE];
struct sockaddr_in server;
struct sockaddr_in client;
int bytes_sent, bytes_received, sin_size;

int main(int argc, char *argv[]){
    if(argc != 2){
        fprintf(stderr, "Usage: ./server PORT_NUMBER\n");
        exit(EXIT_FAILURE);
    }
    PORT_NUM = atoi(argv[1]);

    // 1. Construct a TCP socket to listen connection request
    if((listen_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1){
        perror("Error!\n");
        exit(EXIT_FAILURE);
    }

    // 2. bind address to socket
    bzero(&server, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(PORT_NUM);
    server.sin_addr.s_addr = htonl(INADDR_ANY);
    if(bind(listen_sock, (struct sockaddr *)&server, sizeof(server)) == -1){
        perror("Bind error!\n");
        exit(EXIT_FAILURE);
    }

    // 3. Listen request from client
    if(listen(listen_sock, LISTENQ) == -1){
        perror("Listen error!\n");
        exit(EXIT_FAILURE);
    }

    // 4. Communicate with client
    struct sockaddr_in client_address;
    socklen_t addr_len = sizeof(client_address);
    char buffer[MAX_FILE_SIZE];
    int file_size;

    while (1) {
        sin_size = sizeof(struct sockaddr_in);
        // Accept a connection
        if((conn_sock = accept(listen_sock, (struct sockaddr_in *) &client, &sin_size)) == -1){
            perror("Accept Error!\n");
        }

        // Receive file size
        ssize_t bytes_received = recv(conn_sock, &file_size, sizeof(int), 0);
        if (bytes_received < 0) {
            perror("Failed to receive file size");
            close(conn_sock);
            continue;
        }

        // Receive file data
        bytes_received = recv(conn_sock, buffer, file_size, 0);
        if (bytes_received < 0) {
            perror("Failed to receive file data");
            close(conn_sock);
            continue;
        }

        // Handle the received file data as needed
        // You can save it to a file or process it further

        printf("File received with size: %d bytes\n", file_size);

        // Close the client socket
        close(conn_sock);
    }

    // Close the server socket (not reached in this example)
    close(listen_sock);
    return 0;
    }
