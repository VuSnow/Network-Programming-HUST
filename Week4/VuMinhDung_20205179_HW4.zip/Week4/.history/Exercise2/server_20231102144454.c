#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s Port_Number\n", argv[0]);
        return 1;
    }

    int port = atoi(argv[1]);
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE];

    // Create a directory to save the files
    system("mkdir -p files");

    // Create a socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("Error in socket");
        exit(1);
    }

    // Set up server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind the server socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Error in bind");
        exit(1);
    }

    // Listen for incoming connections
    if (listen(server_socket, 10) == -1) {
        perror("Error in listen");
        exit(1);
    }

    printf("Server is listening on port %d...\n", port);

    while (1) {
        // Accept a connection
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_addr_len);
        if (client_socket == -1) {
            perror("Error in accept");
            continue;
        }

        // Receive the file name from the client
        int file_name_length;
        recv(client_socket, &file_name_length, sizeof(file_name_length), 0);
        recv(client_socket, buffer, file_name_length, 0);
        buffer[file_name_length] = '\0';
        char *file_name = buffer;

        // Check if the file already exists
        char file_path[100];
        // snprintf(file_path, sizeof(file_path), "files/%s", file_name);
        if (access(file_path, F_OK) != -1) {
            printf("%s Error: File is existed on server\n", file_name);
            send(client_socket, "EXISTED", 7, 0);
            close(client_socket);
            continue;
        }

        // Receive the file content from the client and save it
        FILE *file = fopen(file_path, "wb");
        if (file == NULL) {
            perror("Error in opening file");
            close(client_socket);
            continue;
        }

        int received_bytes;
        while (1) {
            received_bytes = recv(client_socket, buffer, BUFFER_SIZE, 0);
            if (received_bytes <= 0) {
                break;
            }
            fwrite(buffer, 1, received_bytes, file);
        }
        fclose(file);

        if (received_bytes == -1) {
            printf("%s Error: File transferring is interrupted\n", file_name);
            remove(file_path);
        } else {
            printf("%s Transfer complete\n", file_name);
            send(client_socket, "OK", 2, 0);
        }

        close(client_socket);
    }

    close(server_socket);
    return 0;
}
