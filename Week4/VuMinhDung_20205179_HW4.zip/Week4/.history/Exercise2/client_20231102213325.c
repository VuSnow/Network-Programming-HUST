#include<stdio.h>
#include<string.h>
#include<stdbool.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<unistd.h>
#include<stdlib.h>

#define BUFFER_SIZE 1024
#define MAX_FILE_SIZE (100*1024*1024) //100MB

int client_sock;
struct sockaddr_in server_addr;
char file_path[BUFFER_SIZE];
int file_size;
char buff[BUFFER_SIZE];
int bytes_sent, bytes_received, sin_size;

int main(int argc, char *argv[]){
    if(argc != 3){
        printf("Usage: ./client IP_address PORT_number");
    }

    char *SERVER_IP = argv[1];
    int SERVER_PORT = atoi(argv[2]);

    // 1.Construct socket
    if((client_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        perror("Problem in creating the socket\n");
        exit(EXIT_FAILURE);
    }

    // 2.Specify server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    // 3.Request to connect server
    if(connect(client_sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) < 0){
        perror("Problem in connecting server\n");
        exit(EXIT_FAILURE);
    }

    printf("Connect to server successfully\n");

    // 4.Send file to server
    while(1){
        printf("Insert file path to send to server ");
        if(fgets(file_path, sizeof(file_path), stdin) == NULL || file_path[0] == '\n'){
            break;
        }

        file_path[strcspn(file_path, "\n")] = '\0';

        FILE *file = fopen(file_path, "rb");
        if(file == NULL){
            perror("File is not existed\n");
            continue;
        }

        // get the size of file
        fseek(file, 0, SEEK_END);
        file_size = ftell(file);
        fseek(file, 0, SEEK_SET);

        if(file_size > MAX_FILE_SIZE){
            perror("File is too large (greater than 100MB)");
            fclose(file);
            continue;
        }

        // Read file contents
        fread(buff, 1, file_size, file);
        fclose(file);

        // Send file size
        bytes_sent = send(client_sock, &file_size, sizeof(int), 0);
        if (bytes_sent < 0) {
            perror("Failed to send file size");
            continue;
        }

        // Send file data
        bytes_sent = send(client_sock, buff, file_size, 0);
        if (bytes_sent < 0) {
            perror("Failed to send file data");
            continue;
        }

        printf("File transfer successful\n");
    }
    close(client_sock);
    return 0;
}