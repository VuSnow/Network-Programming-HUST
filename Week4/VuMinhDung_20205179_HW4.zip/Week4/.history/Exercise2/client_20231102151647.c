#include<stdio.h>
#include<string.h>
#include<stdbool.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<unistd.h>
#include<stdlib.h>

#define BUFFER_SIZE 1024

int client_sock;
struct sockaddr_in server_addr;
char buffer[BUFFER_SIZE];
int bytes_sent, bytes_received, sin_size;

int main(int argc, char *argv[]){
    if(argc != 3){
        printf("Usage: ./client IP_address PORT_number");
    }

    char *SERVER_IP = argv[1];
    int SERVER_PORT = atoi(argv[2]);

    // 1.Construct socket
    if((client_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        perror("Problem in creating the socket\n");
        exit(EXIT_FAILURE);
    }

    // 2.Specify server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    // 3.Request to connect server
    if(connect(client_sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) < 0){
        perror("Problem in connecting server\n");
        exit(EXIT_FAILURE);
    }

    
}