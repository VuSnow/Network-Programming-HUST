/*UDP Echo Server*/
#include <stdio.h> /* These are the usual header files */
#include <sys/types.h>

#include <winsock2.h>

// #include <sys/socket.h>
// #include <netinet/in.h>
// #include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>

#define BUFF_SIZE 1024
#define MAX_USERNAME_LENGTH 50
#define MAX_PASSWORD_LENGTH 50
#define MAX_CLIENTS 50

// node list
typedef struct
{
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    int status;
    int attempts;
    struct node *next;
} node;

node *make_node(char username[], char password[], int status, int attempts)
{
    node *cur = (node *)malloc(sizeof(node));

    strcpy(cur->username, username);
    strcpy(cur->password, password);
    cur->status = status;
    cur->attempts = attempts;
    cur->next = NULL;

    return cur;
}
node *read_data_file()
{
    FILE *fp;
    node *dummy = NULL;
    node *cur = NULL;
    dummy = make_node("", "", 0, 0);

    fp = fopen("accounts.txt", "r");
    if (fp == NULL)
    {
        printf("Can't find file!");
        return NULL;
    }

    char username[MAX_USERNAME_LENGTH], password[MAX_PASSWORD_LENGTH];
    int status;

    cur = dummy;
    while (!feof(fp))
    {
        fscanf(fp, "%s %s %d\n", username, password, &status);
        cur->next = make_node(username, password, status, 0);
        cur = cur->next;
    }

    fclose(fp);
    return dummy->next;
}

void write_data_file(node *head)
{
    FILE *fp;

    fp = fopen("accounts.txt", "w");
    if (fp == NULL)
    {
        printf("Can't find file!");
        return NULL;
    }

    node *cur = head;
    while (cur)
    {
        fprintf(fp, "%s %s %d\n", cur->username, cur->password, cur->status);
        cur = cur->next;
    }

    fclose(fp);
}

node *search(node *head, char *username)
{
    node *temp = head;
    while (temp != NULL)
    {
        if (strcmp(temp->username, username) == 0)
        {
            return temp;
        }
        temp = temp->next;
    }
    return NULL;
}

// account list
typedef struct
{
    node *info;
    struct sockaddr_in client;
    struct account *next;
} account;

account *make_account(node *info, struct sockaddr_in client)
{
    account *cur = (account *)malloc(sizeof(account));

    cur->info = info;
    cur->client = client;
    cur->next = NULL;

    return cur;
}

account *add_to_account_list(account *head, account *temp)
{
    temp->next = head;
    head = temp;
    return head;
}

void get_log_info(char *username, char *password, char *buff)
{
    int u_in = 0, p_in = 0, shift = 0; // Index for 2 results strings
    for (int i = 0; i < strlen(buff); i++)
    {
        if (buff[i] == ' ')
        {
            shift = 1;
            continue;
        }
        if (shift == 0)
            username[u_in++] = buff[i];
        else
            password[p_in++] = buff[i];
    }

    username[u_in++] = '\0';
    password[p_in++] = '\0';
}

// Returns 1 if the input is valid, 0 otherwise. Also split the input string into 2 required parts
int split(char *alpha, char *numeric, char *input)
{
    int a_in = 0, n_in = 0; // Index for 2 results strings
    for (int i = 0; i < strlen(input); i++)
    {
        if (isalpha(input[i]))
            alpha[a_in++] = input[i];
        else if (isdigit(input[i]))
            numeric[n_in++] = input[i];
        else
            return 0;
    }

    alpha[a_in] = '\0';
    numeric[n_in] = '\0';
    return 1;
}

int change_password(node **head, char username[MAX_USERNAME_LENGTH], char new_password[MAX_PASSWORD_LENGTH])
{
    node *temp = *head;
    while (temp)
    {
        if (strcmp(temp->username, username) == 0)
            break;
        temp = temp->next;
    }
    if (!temp)
        return 0;

    strcpy(temp->password, new_password);
    write_data_file(*head);
    return 1;
}

int main(int argc, char *argv[]) // Pass in the Command Line that specifies that Port number
{
    // Get account list
    node *head = read_data_file();
    account *acc_head = NULL;
    // Server Stuff
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        printf("WSAStartup failed with error: %d\n", WSAGetLastError());
        return 1;
    }
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s PortNumber\n", argv[0]);
        exit(1);
    }

    int server_sock; /* file descriptors */
    char buff[BUFF_SIZE];
    int bytes_sent, bytes_received;
    struct sockaddr_in server; /* server's address information */
    int sin_size = sizeof(struct sockaddr);

    // Step 1: Construct a UDP socket
    if ((server_sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    { /* calls socket() */
        perror("\nError: Cannot create socket!");
        exit(0);
    }

    // Step 2: Bind address to socket
    int port_num = atoi(argv[1]);
    server.sin_family = AF_INET;
    server.sin_port = htons(port_num);
    server.sin_addr.s_addr = INADDR_ANY; /* INADDR_ANY puts your IP address automatically */
    // bzero(&(server.sin_zero), 8);        /* zero the rest of the structure */

    if (bind(server_sock, (struct sockaddr *)&server, sizeof(struct sockaddr)) == SOCKET_ERROR)
    { /* calls bind() */
        perror("\nError: Cannot bind port number to server");
        exit(0);
    }

    printf("Binding Finished!\n");

    // OLD VER
    //
    // printf("Waiting ... \n");
    // int client_cnt = 0;
    // while (client_cnt < 1)
    // {
    //     // Wait for the first client
    //     //     bytes_received = recvfrom(server_sock, buff, BUFF_SIZE - 1, 0, (struct sockaddr *)&client1, &sin_size);
    //     if (recvfrom(server_sock, buff, BUFF_SIZE, 0, (struct sockaddr *)&client1, &sin_size) >= 0)
    //     {
    //         client_cnt++;
    //         printf("Client 1 connected: %s\n", inet_ntoa(client1.sin_addr));
    //     }
    // }
    // while (client_cnt < 2)
    // { //     bytes_received = recvfrom(server_sock, buff, BUFF_SIZE - 1, 0, (struct sockaddr *)&client1, &sin_size);
    //     if (recvfrom(server_sock, buff, BUFF_SIZE, 0, (struct sockaddr *)&client2, &sin_size) >= 0)
    //     {
    //         if (client2.sin_port != client1.sin_port)
    //         {
    //             client_cnt++;
    //             printf("Client 2 connected: %s\n", inet_ntoa(client2.sin_addr));
    //         }
    //     }
    // }

    printf("Waiting for Clients to Log in...\n");
    while (1)
    {
        struct sockaddr_in client_from, client_to;
        buff[0] = '\0';
        // Receive data from client

        bytes_received = recvfrom(server_sock, buff, BUFF_SIZE, 0, (struct sockaddr *)&client_from, &sin_size);
        buff[bytes_received] = '\0';
        // printf("HERE\n");

        if (bytes_received == 1)
            break;

        if (bytes_received == SOCKET_ERROR)
        {
            printf("Error receiving data from client.\n");
            break;
        }

        // check for type of request (logged in or not)
        int request;
        request = atoi(&buff[0]);
        if (request == 0)
        {
            char username[MAX_USERNAME_LENGTH] = "", password[MAX_PASSWORD_LENGTH] = "";
            get_log_info(username, password, buff + sizeof(char));
            // printf("%s.-%s.\n", username, password);
            node *can = search(head, username);
            if (can == NULL)
            {
                bytes_sent = sendto(server_sock, "Wrong Username!", strlen("Wrong Username!"), 0, (struct sockaddr *)&client_from, sin_size);
                if (bytes_sent == SOCKET_ERROR)
                {
                    printf("Error sending data to client.\n");
                }
                continue;
            }

            if (strcmp(can->password, password) != 0)
            {
                can->attempts++;
                char wrong_pass_msg[100];
                if (can->attempts >= 3)
                {
                    can->status = 0;
                    strcpy(wrong_pass_msg, "Wrong password 3 times. Account deactivated");
                    write_data_file(head);
                }
                else
                {
                    strcpy(wrong_pass_msg, "Wrong Password!");
                }
                bytes_sent = sendto(server_sock, wrong_pass_msg, strlen(wrong_pass_msg), 0, (struct sockaddr *)&client_from, sin_size);
                if (bytes_sent == SOCKET_ERROR)
                {
                    printf("Error sending data to client.\n");
                }
                continue;
            }

            if (can->status == 0)
            {
                bytes_sent = sendto(server_sock, "Account not active!", strlen("Account not active!"), 0, (struct sockaddr *)&client_from, sin_size);
                if (bytes_sent == SOCKET_ERROR)
                {
                    printf("Error sending data to client.\n");
                }
                continue;
            }

            bytes_sent = sendto(server_sock, "OK", strlen("OK"), 0, (struct sockaddr *)&client_from, sin_size);
            if (bytes_sent == SOCKET_ERROR)
            {
                printf("Error sending data to client.\n");
                continue;
            }

            // update current logged in list

            account *temp = make_account(can, client_from);
            acc_head = add_to_account_list(acc_head, temp);

            node *cur = head;
            while (cur)
            {
                cur->attempts = 0;
                cur = cur->next;
            }
            printf("New client connected!\n");
        }
        else
        {
            if (strcmp(buff, "1bye") == 0) // user wants log out
            {
                char byeMsg[BUFF_SIZE] = "Goodbye ";
                account *temp = acc_head;
                while (temp)
                {
                    if (temp->client.sin_port == client_from.sin_port)
                        break;
                    temp = temp->next;
                }

                if (temp)
                    strcat(byeMsg, temp->info->username);

                bytes_sent = sendto(server_sock, byeMsg, strlen(byeMsg), 0, (struct sockaddr *)&client_from, sin_size); // Indicate closing
                if (bytes_sent == SOCKET_ERROR)
                {
                    printf("Error sending data to client.\n");
                    continue;
                }

                temp = acc_head;
                account *prev = NULL;
                while (temp != NULL)
                {
                    if (temp->client.sin_port == client_from.sin_port)
                    {
                        // Found the node to delete
                        break;
                    }
                    prev = temp;
                    temp = temp->next;
                }

                if (temp != NULL)
                {
                    if (prev != NULL)
                    {
                        prev->next = temp->next;
                    }
                    else
                    {
                        acc_head = temp->next;
                    }
                }
                free(temp);
                continue;
            }
            char alpha[BUFF_SIZE] = "", numeric[BUFF_SIZE] = "";

            if (split(alpha, numeric, buff + sizeof(char)))
            {
                char result[BUFF_SIZE * 2 + 1], username[MAX_USERNAME_LENGTH];
                sprintf(result, "%s;%s", alpha, numeric);
                // change password
                account *temp = acc_head;
                while (temp)
                {
                    if (temp->client.sin_port == client_from.sin_port)
                        break;
                    temp = temp->next;
                }

                if (temp)
                {
                    strcpy(username, temp->info->username);
                    change_password(&head, username, buff + sizeof(char));
                }

                // Send data to other clients

                temp = acc_head;
                while (temp)
                {
                    client_to = temp->client;
                    bytes_sent = sendto(server_sock, result, strlen(result), 0, (struct sockaddr *)&client_to, sin_size);

                    temp = temp->next;
                }
                if (bytes_sent == SOCKET_ERROR)
                {
                    printf("Error sending data to client.\n");
                    break;
                }
            }
            else
            {
                // If the input is invalid, send an error message to the client
                account *temp = acc_head;
                while (temp)
                {
                    if (temp->client.sin_port != client_from.sin_port)
                    {
                        client_to = temp->client;
                        bytes_sent = sendto(server_sock, "Error", strlen("Error"), 0, (struct sockaddr *)&client_to, sin_size);
                    }
                    temp = temp->next;
                }
                if (bytes_sent == SOCKET_ERROR)
                {
                    printf("Error sending data to client.\n");
                    break;
                }
            }
        }
    }

    printf("Closing ...\n");
    closesocket(server_sock);
    WSACleanup();
    return 0;
}
