/*UDP Echo Client*/
#include <stdio.h> /* These are the usual header files */
#include <sys/types.h>

// #include <sys/socket.h>
#include <winsock2.h>
#include <string.h>

#include <pthread.h>
// #include <netinet/in.h>

// #include <arpa/inet.h>

#include <string.h>
#include <unistd.h>
#define BUFF_SIZE 1024
#define MAX_USERNAME_LENGTH 50
#define MAX_PASSWORD_LENGTH 50

pthread_t thread_send_id;
pthread_t thread_receive_id;
int client_sock;
int flag = 0;
char buff[BUFF_SIZE];
int bytes_sent, bytes_received, sin_size, approved = 0;
char byeMsg[BUFF_SIZE] = "Goodbye ";

struct sockaddr_in server_addr;
void receiveMsg()
{
    while (1)
    {
        buff[0] = '\0';
        bytes_received = recvfrom(client_sock, buff, BUFF_SIZE - 1, 0, (struct sockaddr *)&server_addr, &sin_size);
        // bytes_received = recv(client_sock, buff, BUFF_SIZE - 1, 0);
        buff[bytes_received] = '\0';

        if (strcmp(buff, byeMsg) == 0)
        {
            printf("%s\n", byeMsg);
            approved = 0;
            break;
        }
        if (bytes_received == 1) // Break if user enters empty string
        {
            flag = 1;
            break;
        }

        if (bytes_received < 0)
        {
            flag = 1;
            break;
        }

        buff[bytes_received] = '\0';
        char *alpha = strtok(buff, ";");
        char *numeric = strtok(NULL, ";");

        printf("\nReceived Message: \n");
        if (alpha != NULL)
            printf("%s\n", alpha);

        if (numeric != NULL)
            printf("%s\n", numeric);

        printf("\nInsert string to send:\n>");
    }
}

void sendMsg()
{
    while (1)
    {
        buff[0] = '\0';
        char msg[BUFF_SIZE];

        printf("\nInsert string to send:\n>");
        memset(msg, '\0', (strlen(msg) + 1));
        fgets(msg, BUFF_SIZE, stdin);
        msg[strlen(msg) - 1] = '\0';

        strcpy(buff, "1");
        strcat(buff, msg);

        bytes_sent = sendto(client_sock, buff, strlen(buff), 0, (struct sockaddr *)&server_addr, sin_size);
        if (strcmp(msg, "bye") == 0)
        {
            // approved = 0;
            break;
        }
        if (bytes_sent == 1) // Break if user enters empty string
        {
            flag = 1;
            break;
        }

        // bytes_sent = send(client_sock, buff, strlen(buff), 0);
        if (bytes_sent < 0)
        {
            printf("Error when sending!\n");
            {
                flag = 1;
                break;
            }
        }
    }
}

int main(int argc, char *argv[])
{
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        printf("WSAStartup failed with error: %d\n", WSAGetLastError());
        return 1;
    }
    if (argc != 3)
    {
        fprintf(stderr, "Usage: %s <IP address> <port number>\n", argv[0]);
        exit(1);
    }

    char *ip_address = argv[1];
    int port_number = atoi(argv[2]);

    // Step 1: Construct a UDP socket
    if ((client_sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    { /* calls socket() */
        perror("\nError: ");
        exit(0);
    }

    // Step 2: Define the address of the server
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port_number);
    server_addr.sin_addr.s_addr = inet_addr(ip_address);

    printf("Connect successfully");

    sin_size = sizeof(struct sockaddr);

    while (!flag)
    {
        if (!approved)
        {
            while (1)
            {
                char username[MAX_USERNAME_LENGTH];
                char password[MAX_PASSWORD_LENGTH];
                char msg[MAX_USERNAME_LENGTH + MAX_PASSWORD_LENGTH + 1] = "0";

                printf("\nEnter username: ");
                fgets(username, MAX_USERNAME_LENGTH, stdin);
                username[strlen(username) - 1] = '\0';

                printf("Enter password: ");
                fgets(password, MAX_PASSWORD_LENGTH, stdin);
                password[strlen(password) - 1] = '\0';

                strcat(msg, username);
                strcat(msg, " ");
                strcat(msg, password);
                // printf("SENT: .%s.\n", msg);
                bytes_sent = sendto(client_sock, msg, strlen(msg), 0, (struct sockaddr *)&server_addr, sin_size);
                if (bytes_sent == 1) // Break if user enters empty string
                    break;

                if (bytes_sent < 0)
                {
                    printf("Error when sending!\n");
                    break;
                }

                buff[0] = '\0';
                bytes_received = recvfrom(client_sock, buff, BUFF_SIZE - 1, 0, (struct sockaddr *)&server_addr, &sin_size);
                buff[bytes_received] = '\0';
                if (bytes_received == 1) // Break if user enters empty string
                    break;

                if (bytes_received < 0)
                    break;

                if (strcmp(buff, "OK") == 0)
                {
                    approved = 1;
                    strcpy(byeMsg, "Goodbye ");
                    strcat(byeMsg, username);
                    printf("%s\n", buff);
                    break;
                }
                else
                    printf("%s\n", buff);
            }
        }
        else
        {
            // Step 3: Communicate with server
            if (pthread_create(&thread_send_id, NULL, (void *)sendMsg, NULL) != 0)
            {
                printf("ERROR: pthread\n");
                return EXIT_FAILURE;
            }

            if (pthread_create(&thread_receive_id, NULL, (void *)receiveMsg, NULL) != 0)
            {
                printf("ERROR: pthread\n");
                return EXIT_FAILURE;
            }

            while (1)
            {
                if (!approved)
                    break;
            }
        }
    }
    printf("Closing ...\n");
    closesocket(client_sock);
    WSACleanup();

    return 0;
}
