#include <stdio.h>
// #include <netinet/in.h>
// #include <arpa/inet.h>
// #include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include <winsock2.h>

#define BUFF_SIZE 1024
#define MAX_USERNAME_LENGTH 50
#define MAX_PASSWORD_LENGTH 50

int main(int argc, char *argv[])
{
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
	{
		printf("WSAStartup failed with error: %d\n", WSAGetLastError());
		return 1;
	}

	int client_sock;
	struct sockaddr_in server_addr; /* server's address information */
	int msg_len, bytes_sent, bytes_received;
	char *ip_address = argv[1];
	char buff[BUFF_SIZE];
	int port_num = atoi(argv[2]);

	// Step 1: Construct socket
	client_sock = socket(AF_INET, SOCK_STREAM, 0);

	// Step 2: Specify server address
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(port_num);
	server_addr.sin_addr.s_addr = inet_addr(ip_address);

	// Step 3: Request to connect server
	if (connect(client_sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) < 0)
	{
		printf("\nError!Can not connect to sever! Client exit immediately!");
		return 0;
	}

	int approved = 0;
	while (!approved)
	{
		char username[MAX_USERNAME_LENGTH];
		char password[MAX_PASSWORD_LENGTH];
		char msg[MAX_USERNAME_LENGTH + MAX_PASSWORD_LENGTH + 1] = "";

		printf("\nEnter username: ");
		fgets(username, MAX_USERNAME_LENGTH, stdin);
		username[strlen(username) - 1] = '\0';

		printf("Enter password: ");
		fgets(password, MAX_PASSWORD_LENGTH, stdin);
		password[strlen(password) - 1] = '\0';

		strcpy(msg, username);
		strcat(msg, " ");
		strcat(msg, password);
		bytes_sent = send(client_sock, msg, strlen(msg), 0);

		if (bytes_sent < 0)
		{
			printf("Error when sending!\n");
			break;
		}

		buff[0] = '\0';
		bytes_received = recv(client_sock, buff, BUFF_SIZE - 1, 0);
		buff[bytes_received] = '\0';

		if (bytes_received < 0)
			break;

		if (strcmp(buff, "Approved") == 0)
		{
			approved = 1;
			printf("%s\n", buff);
			break;
		}
		else
			printf("%s\n", buff);
	}
	while (approved)
	{
		char cmd[100];
		printf("\nPress 0 to Log Out: ");
		fgets(cmd, 100, stdin);
		cmd[strlen(cmd) - 1] = '\0';
		if (strcmp(cmd, "0") == 0)
		{
			bytes_sent = send(client_sock, "LogOut", strlen("LogOut"), 0);
			if (bytes_sent < 0)
			{
				printf("Error when sending!\n");
				break;
			}
		}
		else
		{
			printf("Wrong Command!\n");
			continue;
		}
		bytes_received = recv(client_sock, buff, BUFF_SIZE - 1, 0);
		buff[bytes_received] = '\0';

		if (bytes_received < 0)
			break;

		printf("%s\n", buff);
		break;
	}
	printf("Closing ...\n");
	closesocket(client_sock);
	WSACleanup();

	return 0;
}
