#include <stdio.h> /* These are the usual header files */
#include <sys/types.h>
// #include <sys/socket.h>
// #include <netinet/in.h>
// #include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <winsock2.h>
#include <pthread.h>
#include <ctype.h>

#define BACKLOG 5 /* Number of allowed connections */
#define BUFF_SIZE 1024
#define MAX_USERNAME_LENGTH 50
#define MAX_PASSWORD_LENGTH 50

void *communicate(void *);
// node list
typedef struct
{
	char username[MAX_USERNAME_LENGTH];
	char password[MAX_PASSWORD_LENGTH];
	int status;
	int attempts;
	struct node *next;
} node;

node *make_node(char username[], char password[], int status, int attempts)
{
	node *cur = (node *)malloc(sizeof(node));

	strcpy(cur->username, username);
	strcpy(cur->password, password);
	cur->status = status;
	cur->attempts = attempts;
	cur->next = NULL;

	return cur;
}
node *read_data_file()
{
	FILE *fp;
	node *dummy = NULL;
	node *cur = NULL;
	dummy = make_node("", "", 0, 0);

	fp = fopen("accounts.txt", "r");
	if (fp == NULL)
	{
		printf("Can't find file!");
		return NULL;
	}

	char username[MAX_USERNAME_LENGTH], password[MAX_PASSWORD_LENGTH];
	int status;

	cur = dummy;
	while (!feof(fp))
	{
		fscanf(fp, "%s %s %d\n", username, password, &status);
		cur->next = make_node(username, password, status, 0);
		cur = cur->next;
	}

	fclose(fp);
	return dummy->next;
}

void write_data_file(node *head)
{
	FILE *fp;

	fp = fopen("accounts.txt", "w");
	if (fp == NULL)
	{
		printf("Can't find file!");
		return NULL;
	}

	node *cur = head;
	while (cur)
	{
		fprintf(fp, "%s %s %d\n", cur->username, cur->password, cur->status);
		cur = cur->next;
	}

	fclose(fp);
}

node *search(node *head, char *username)
{
	node *temp = head;
	while (temp != NULL)
	{
		if (strcmp(temp->username, username) == 0)
		{
			return temp;
		}
		temp = temp->next;
	}
	return NULL;
}

// account list
typedef struct
{
	node *info;
	struct sockaddr_in client;
	struct account *next;
} account;

account *make_account(node *info, struct sockaddr_in client)
{
	account *cur = (account *)malloc(sizeof(account));

	cur->info = info;
	cur->client = client;
	cur->next = NULL;

	return cur;
}

account *add_to_account_list(account *head, account *temp)
{
	temp->next = head;
	head = temp;
	return head;
}

void get_log_info(char *username, char *password, char *buff)
{
	int u_in = 0, p_in = 0, shift = 0; // Index for 2 results strings
	for (int i = 0; i < strlen(buff); i++)
	{
		if (buff[i] == ' ')
		{
			shift = 1;
			continue;
		}
		if (shift == 0)
			username[u_in++] = buff[i];
		else
			password[p_in++] = buff[i];
	}

	username[u_in++] = '\0';
	password[p_in++] = '\0';
}

// Returns 1 if the input is valid, 0 otherwise. Also split the input string into 2 required parts
int split(char *alpha, char *numeric, char *input)
{
	int a_in = 0, n_in = 0; // Index for 2 results strings
	for (int i = 0; i < strlen(input); i++)
	{
		if (isalpha(input[i]))
			alpha[a_in++] = input[i];
		else if (isdigit(input[i]))
			numeric[n_in++] = input[i];
		else
			return 0;
	}

	alpha[a_in] = '\0';
	numeric[n_in] = '\0';
	return 1;
}
int main(int argc, char *argv[])
{
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
	{
		printf("WSAStartup failed with error: %d\n", WSAGetLastError());
		return 1;
	}

	if (argc != 2)
	{
		fprintf(stderr, "Usage: %s PortNumber\n", argv[0]);
		exit(1);
	}

	int listen_sock, *conn_sock; /* file descriptors */
	int bytes_sent, bytes_received;
	struct sockaddr_in server; /* server's address information */
	struct sockaddr_in client; /* client's address information */
	int sin_size = sizeof(struct sockaddr);
	int port_num = atoi(argv[1]);
	pthread_t tid;

	// Step 1: Construct a TCP socket to listen connection request
	if ((listen_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{ /* calls socket() */
		perror("\nError: ");
		return 0;
	}

	// Step 2: Bind address to socket
	bzero(&server, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(port_num);			/* Remember htons() from "Conversions" section? =) */
	server.sin_addr.s_addr = htonl(INADDR_ANY); /* INADDR_ANY puts your IP address automatically */
	if (bind(listen_sock, (struct sockaddr *)&server, sizeof(server)) == -1)
	{ /* calls bind() */
		perror("\nError: ");
		return 0;
	}
	printf("Binding Finished!\n");

	// Step 3: Listen request from client
	if (listen(listen_sock, BACKLOG) == -1)
	{ /* calls listen() */
		perror("\nError: ");
		return 0;
	}

	// Step 4: Communicate with client
	while (1)
	{
		conn_sock = malloc(sizeof(int));
		if ((*conn_sock = accept(listen_sock, (struct sockaddr *)&client, &sin_size)) == -1)
			perror("\nError: ");

		printf("You got a connection from %s\n", inet_ntoa(client.sin_addr)); /* prints client's IP */

		/* For each client, spawns a thread, and the thread handles the new client */
		pthread_create(&tid, NULL, &communicate, conn_sock);
	}

	closesocket(listen_sock);
	WSACleanup();
	return 0;
}

void *communicate(void *arg)
{
	int conn_sock;
	int loged_in = 0;
	int bytes_sent, bytes_received;
	char buff[BUFF_SIZE + 1];
	struct sockaddr_in client_from, client_to;

	conn_sock = *((int *)arg);
	free(arg);
	pthread_detach(pthread_self());

	node *head = read_data_file(); // get all accounts details
	account *acc_head = NULL;	

	while (1)
	{
		buff[0] = '\0';
		bytes_received = recv(conn_sock, buff, BUFF_SIZE, 0); // blocking
		buff[bytes_received] = '\0';

		if (bytes_received == 1)
			break;

		if (bytes_received == SOCKET_ERROR)
		{
			printf("Error receiving data from client.\n");
			break;
		}

		if (!loged_in)
		{
			char username[MAX_USERNAME_LENGTH] = "", password[MAX_PASSWORD_LENGTH] = "";
			get_log_info(username, password, buff);
			// printf("%s.-%s.\n", username, password);
			node *can = search(head, username);
			if (can == NULL)
			{
				bytes_sent = send(conn_sock, "Wrong Username!", strlen("Wrong Username!"), 0);
				if (bytes_sent == SOCKET_ERROR)
				{
					printf("Error sending data to client.\n");
				}
				continue;
			}

			if (strcmp(can->password, password) != 0)
			{
				can->attempts++;
				char wrong_pass_msg[100];
				if (can->attempts >= 3)
				{
					can->status = 0;
					strcpy(wrong_pass_msg, "Wrong password 3 times. Account deactivated");
					write_data_file(head);
				}
				else
				{
					strcpy(wrong_pass_msg, "Wrong Password!");
				}
				bytes_sent = send(conn_sock, wrong_pass_msg, strlen(wrong_pass_msg), 0);

				if (bytes_sent == SOCKET_ERROR)
				{
					printf("Error sending data to client.\n");
				}
				continue;
			}

			if (can->status == 0)
			{
				bytes_sent = send(conn_sock, "Account not active!", strlen("Account not active!"), 0);

				if (bytes_sent == SOCKET_ERROR)
				{
					printf("Error sending data to client.\n");
				}
				continue;
			}
			bytes_sent = send(conn_sock, "Approved", strlen("Approved"), 0);

			if (bytes_sent == SOCKET_ERROR)
			{
				printf("Error sending data to client.\n");
				continue;
			}

			// update current logged in list

			account *temp = make_account(can, client_from);
			acc_head = add_to_account_list(acc_head, temp);

			node *cur = head;
			while (cur)
			{
				cur->attempts = 0;
				cur = cur->next;
			}
			printf("New client connected!\n");
			loged_in = 1;
		}
		else
		{
			if (strcmp(buff, "LogOut") == 0)
			{
				char byeMsg[BUFF_SIZE] = "Goodbye ";
				account *temp = acc_head;
				while (temp)
				{
					if (temp->client.sin_port == client_from.sin_port)
						break;
					temp = temp->next;
				}

				strcat(byeMsg, temp->info->username);
				printf("Client: %s Logged Out!\n", temp->info->username);

				bytes_sent = send(conn_sock, byeMsg, strlen(byeMsg), 0);
				if (bytes_sent == SOCKET_ERROR)
				{
					printf("Error sending data to client.\n");
					continue;
				}

				temp = acc_head;
				account *prev = NULL;
				while (temp != NULL)
				{
					if (temp->client.sin_port == client_from.sin_port)
					{
						// Found the node to delete
						break;
					}
					prev = temp;
					temp = temp->next;
				}

				if (temp != NULL)
				{
					if (prev != NULL)
					{
						prev->next = temp->next;
					}
					else
					{
						acc_head = temp->next;
					}
				}
				free(temp);
				break;
			}
		}
	}
}