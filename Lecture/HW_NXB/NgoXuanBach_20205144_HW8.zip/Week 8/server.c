#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#define BUFFER_SIZE 1024
#define MAX_CLIENTS 10

void log_client_info(const char *client_address, int client_port)
{
    char log_filename[50];
    sprintf(log_filename, "client_%s_%d.log", client_address, client_port);

    // Get OS information
    char os_info[50];
    OSVERSIONINFO osvi;
    osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
    GetVersionEx(&osvi);
    sprintf(os_info, "Windows %d.%d", osvi.dwMajorVersion, osvi.dwMinorVersion);

    // Get hardware information
    char hardware_info[50];
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    sprintf(hardware_info, "Processor Architecture: %u", si.wProcessorArchitecture);

    char log_message[500];
    sprintf(log_message, "Client IP: %s\nClient Port: %d\nOS: %s\nHardware: %s\n", client_address, client_port, os_info, hardware_info);

    FILE *log_file = fopen(log_filename, "w");
    if (log_file)
    {
        fputs(log_message, log_file);
        fclose(log_file);
    }
    printf("Client %d's information has been saved!", client_port);
}

int main(int argc, char *argv[])
{
    int port = atoi(argv[1]);

    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        perror("Failed with Winsock");
        exit(EXIT_FAILURE);
    }

    SOCKET server_socket, new_socket;
    struct sockaddr_in server_address, client_address;
    int client_address_len = sizeof(client_address);
    char buffer[BUFFER_SIZE];
    fd_set read_fds;
    SOCKET client_sockets[MAX_CLIENTS] = {0};

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == INVALID_SOCKET)
    {
        perror("Socket create failed");
        exit(EXIT_FAILURE);
    }

    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(port);

    if (bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) == SOCKET_ERROR)
    {
        perror("Binding failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_socket, 1) == SOCKET_ERROR)
    {
        perror("Listening failed");
        exit(EXIT_FAILURE);
    }

    printf("Server is running. Waiting for connections...\n");

    while (1)
    {
        FD_ZERO(&read_fds);
        FD_SET(server_socket, &read_fds);

        SOCKET max_sd = server_socket;
        for (int i = 0; i < MAX_CLIENTS; i++)
        {
            SOCKET sd = client_sockets[i];
            if (sd > 0)
            {
                FD_SET(sd, &read_fds);
                if (sd > max_sd)
                {
                    max_sd = sd;
                }
            }
        }

        int activity = select(max_sd + 1, &read_fds, NULL, NULL, NULL);
        if (activity == SOCKET_ERROR)
        {
            perror("Select failed");
            exit(EXIT_FAILURE);
        }

        if (FD_ISSET(server_socket, &read_fds))
        {
            new_socket = accept(server_socket, (struct sockaddr *)&client_address, &client_address_len);
            if (new_socket == INVALID_SOCKET)
            {
                perror("Acceptance failed");
                exit(EXIT_FAILURE);
            }

            char client_ip[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &(client_address.sin_addr), client_ip, INET_ADDRSTRLEN);
            int client_port = ntohs(client_address.sin_port);

            printf("New connection from %s:%d\n", client_ip, client_port);

            for (int i = 0; i < MAX_CLIENTS; i++)
            {
                if (client_sockets[i] == 0)
                {
                    client_sockets[i] = new_socket;
                    break;
                }
            }
        }

        for (int i = 0; i < MAX_CLIENTS; i++)
        {
            SOCKET sd = client_sockets[i];

            if (FD_ISSET(sd, &read_fds))
            {
                memset(buffer, 0, sizeof(buffer));

                int bytes_received = recv(sd, buffer, sizeof(buffer), 0);
                if (bytes_received == 1)
                    break;
                if (bytes_received == 0)
                {
                    char client_ip[INET_ADDRSTRLEN];
                    getpeername(sd, (struct sockaddr *)&client_address, &client_address_len);
                    inet_ntop(AF_INET, &(client_address.sin_addr), client_ip, INET_ADDRSTRLEN);
                    int client_port = ntohs(client_address.sin_port);

                    printf("Client %s:%d disconnected\n", client_ip, client_port);

                    closesocket(sd);
                    client_sockets[i] = 0;
                }
                else
                {
                    char client_ip[INET_ADDRSTRLEN];
                    getpeername(sd, (struct sockaddr *)&client_address, &client_address_len);
                    inet_ntop(AF_INET, &(client_address.sin_addr), client_ip, INET_ADDRSTRLEN);
                    int client_port = ntohs(client_address.sin_port);

                    printf("Received data from %s:%d\n", client_ip, client_port);

                    log_client_info(client_ip, client_port);
                }
            }
        }
    }

    closesocket(server_socket);
    WSACleanup();

    return 0;
}
