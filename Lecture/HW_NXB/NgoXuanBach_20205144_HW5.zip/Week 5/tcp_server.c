#include <stdio.h> /* These are the usual header files */
#include <sys/types.h>
// #include <sys/socket.h>
// #include <netinet/in.h>
// #include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <winsock2.h>
#include <ctype.h>

#define BACKLOG 2 /* Number of allowed connections */
#define BUFF_SIZE 1024

// Returns 1 if the input is valid, 0 otherwise. Also split the input string into 2 required parts
int split(char *alpha, char *numeric, char *input)
{
	int a_in = 0, n_in = 0; // Index for 2 results strings
	for (int i = 0; i < strlen(input); i++)
	{
		if (isalpha(input[i]))
			alpha[a_in++] = input[i];
		else if (isdigit(input[i]))
			numeric[n_in++] = input[i];
		else
			return 0;
	}

	alpha[a_in] = '\0';
	numeric[n_in] = '\0';
	return 1;
}
int main(int argc, char *argv[])
{
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
	{
		printf("WSAStartup failed with error: %d\n", WSAGetLastError());
		return 1;
	}

	if (argc != 2)
	{
		fprintf(stderr, "Usage: %s PortNumber\n", argv[0]);
		exit(1);
	}

	int listen_sock, conn_sock; /* file descriptors */
	int bytes_sent, bytes_received;
	struct sockaddr_in server; /* server's address information */
	struct sockaddr_in client; /* client's address information */
	int sin_size = sizeof(struct sockaddr);
	int port_num = atoi(argv[1]);

	// Step 1: Construct a TCP socket to listen connection request
	if ((listen_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{ /* calls socket() */
		perror("\nError: ");
		return 0;
	}

	// Step 2: Bind address to socket
	bzero(&server, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(port_num);			/* Remember htons() from "Conversions" section? =) */
	server.sin_addr.s_addr = htonl(INADDR_ANY); /* INADDR_ANY puts your IP address automatically */
	if (bind(listen_sock, (struct sockaddr *)&server, sizeof(server)) == -1)
	{ /* calls bind() */
		perror("\nError: ");
		return 0;
	}
	printf("Binding Finished!\n");

	// Step 3: Listen request from client
	if (listen(listen_sock, BACKLOG) == -1)
	{ /* calls listen() */
		perror("\nError: ");
		return 0;
	}

	// Step 4: Communicate with client
	while (1)
	{
		// accept request
		sin_size = sizeof(struct sockaddr_in);
		if ((conn_sock = accept(listen_sock, (struct sockaddr *)&client, &sin_size)) == -1)
			perror("\nError: ");

		printf("You got a connection from %s\n", inet_ntoa(client.sin_addr)); /* prints client's IP */

		char option[5];
		int bytes_read = recv(conn_sock, option, 4, 0);
		if (bytes_read <= 0)
		{
			printf("\nConnection from %s closed\n", inet_ntoa(client.sin_addr));
			break;
		}
		int choice = atoi(option);
		// start conversation
		while (1)
		{
			char buff[BUFF_SIZE];
			char recv_data[BUFF_SIZE * 10] = "";
			bytes_read = 0;
			bytes_received = 0;

			// receives message from client+
			// receive message length first
			bytes_read = recv(conn_sock, buff, BUFF_SIZE - 1, 0);
			if (bytes_read <= 0)
			{
				printf("\nConnection from %s closed\n", inet_ntoa(client.sin_addr));
				break;
			}
			buff[bytes_read] = '\0';
			int msg_len = atoi(buff);

			while (1)
			{
				bytes_read = recv(conn_sock, buff, BUFF_SIZE - 1, 0);
				if (bytes_read <= 0)
				{
					printf("\nConnection from %s closed\n", inet_ntoa(client.sin_addr));
					break;
				}
				bytes_received += bytes_read;
				buff[bytes_read] = '\0';
				strcat(recv_data, buff);
				// printf("CUR:%s\n", recv_data);

				if (bytes_received >= msg_len) // if msg long enough
					break;
			}

			recv_data[bytes_received] = '\0';
			// printf("\n\nReceive: %s\n", recv_data);

			// echo to client
			if (choice == 1)
			{
				char alpha[BUFF_SIZE * 10] = "", numeric[BUFF_SIZE * 10] = "";

				if (split(alpha, numeric, recv_data))
				{
					char result[BUFF_SIZE * 20 + 1];
					sprintf(result, "%s;%s", alpha, numeric);

					bytes_read = 0;
					int result_len = strlen(result);
					while (bytes_read < result_len)
					{
						int chunk_len = (result_len - bytes_read) > BUFF_SIZE ? BUFF_SIZE : (result_len - bytes_read);

						bytes_sent = send(conn_sock, result + bytes_read, chunk_len, 0);
						if (bytes_sent <= 0)
						{
							printf("\nConnection closed!\n");
							break;
						}
						bytes_read += chunk_len;
					}
				}
				else
				{
					// If the input is invalid, send an error message to the client
					bytes_sent = send(conn_sock, "Error", strlen("Error"), 0);
					if (bytes_sent <= 0)
					{
						printf("\nConnection closed!\n");
						break;
					}
				}
			}
			else if (choice == 2)
			{
				bytes_read = 0;
				while (bytes_read < bytes_received)
				{
					int chunk_len = (bytes_received - bytes_read) > BUFF_SIZE ? BUFF_SIZE : (bytes_received - bytes_read);

					bytes_sent = send(conn_sock, recv_data + bytes_read, chunk_len, 0);
					if (bytes_sent <= 0)
					{
						printf("\nConnection closed!\n");
						break;
					}
					bytes_read += chunk_len;
				}
			}

		} // end conversation
		close(conn_sock);
	}

	closesocket(listen_sock);
	WSACleanup();
	return 0;
}
