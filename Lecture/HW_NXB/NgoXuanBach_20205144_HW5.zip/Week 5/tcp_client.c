#include <stdio.h>
// #include <netinet/in.h>
// #include <arpa/inet.h>
// #include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include <winsock2.h>

#define BUFF_SIZE 1024

int menu()
{
	int choice;
	printf("MENU\n");
	printf("---------------------------\n");
	printf("1. Send any string\n");
	printf("2. Send the contents of a file\n");
	printf("Choose an option: ");
	scanf("%d", &choice);
	fflush(stdin);
	return choice;
}

int main(int argc, char *argv[])
{
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
	{
		printf("WSAStartup failed with error: %d\n", WSAGetLastError());
		return 1;
	}

	int client_sock;
	struct sockaddr_in server_addr; /* server's address information */
	int msg_len, bytes_sent, bytes_received;
	char *ip_address = argv[1];
	int port_num = atoi(argv[2]);

	// Step 1: Construct socket
	client_sock = socket(AF_INET, SOCK_STREAM, 0);

	// Step 2: Specify server address
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(port_num);
	server_addr.sin_addr.s_addr = inet_addr(ip_address);

	// Step 3: Request to connect server
	if (connect(client_sock, (struct sockaddr *)&server_addr, sizeof(struct sockaddr)) < 0)
	{
		printf("\nError!Can not connect to sever! Client exit imediately!");
		return 0;
	}

	int choice = menu();
	// send choice to server
	char option[5];
	sprintf(option, "%d", choice);
	bytes_sent = send(client_sock, option, strlen(option), 0);
	if (bytes_sent <= 0)
	{
		printf("\nConnection closed!\n");
		closesocket(client_sock);
		WSACleanup();
	}
	// Step 4: Communicate with server
	while (1)
	{
		char content[BUFF_SIZE * 10];
		char recv_content[BUFF_SIZE * 10] = "";
		char buff[BUFF_SIZE];
		// get content
		if (choice == 1) // send string
		{
			// send message
			printf("\nInsert string to send:");
			memset(content, '\0', (strlen(content) + 1));
			fgets(content, BUFF_SIZE * 10, stdin);
			content[strlen(content) - 1] = '\0';
		}
		else if (choice == 2) // send file content
		{
			char file_name[100];
			printf("\nEnter file name to send: ");
			memset(file_name, '\0', (strlen(file_name) + 1));
			fgets(file_name, 100, stdin);
			file_name[strlen(file_name) - 1] = '\0';
			strcat(file_name, ".txt");
			// get the content of file
			FILE *fp;
			fp = fopen(file_name, "rb");
			if (fp == NULL)
			{
				printf("Cannot find file!\n");
				continue;
			}

			// Get the size of the file
			fseek(fp, 0, SEEK_END);
			int file_size = ftell(fp);
			rewind(fp);

			char file_content[] = "";
			fread(file_content, sizeof(char), file_size, fp);
			file_content[file_size] = '\0';
			strcpy(content, file_content);
		}
		// send content
		msg_len = strlen(content);
		if (msg_len == 0)
			break;

		// Send streams of data over the TCP socket
		// send message size first
		char msg_size[50];
		sprintf(msg_size, "%d", msg_len);
		bytes_sent = send(client_sock, msg_size, strlen(msg_size), 0);
		if (bytes_sent <= 0)
		{
			printf("\nConnection closed!\n");
			break;
		}
		// send data by chunks to server
		int bytes_read = 0;
		while (bytes_read < msg_len)
		{
			int chunk_len = (msg_len - bytes_read) > BUFF_SIZE ? BUFF_SIZE : (msg_len - bytes_read);

			bytes_sent = send(client_sock, content + bytes_read, chunk_len, 0);
			if (bytes_sent <= 0)
			{
				printf("\nConnection closed!\n");
				break;
			}
			bytes_read += chunk_len;
		}

		// receive echo reply
		bytes_received = 0;
		while (1)
		{
			bytes_read = recv(client_sock, buff, BUFF_SIZE - 1, 0);
			if (bytes_read <= 0)
			{
				printf("\nConnection closed\n");
				break;
			}

			bytes_received += bytes_read;
			buff[bytes_read] = '\0';
			strcat(recv_content, buff);

			if (bytes_received >= msg_len || strcmp(buff, "Error") == 0) // if msg long enough
				break;
		}

		recv_content[bytes_received] = '\0';
		if (choice == 1)
		{
			char *alpha = strtok(recv_content, ";");
			char *numeric = strtok(NULL, ";");

			printf("\nReply from server:\n");
			if (alpha != NULL)
				printf("%s\n", alpha);

			if (numeric != NULL)
				printf("%s\n", numeric);
		}
		else
			printf("\nReply from server:\n%s\n", recv_content);
	}

	// Step 4: Close socket
	printf("Closing ...\n");
	closesocket(client_sock);
	WSACleanup();
	return 0;
}
